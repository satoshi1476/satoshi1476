package com.neemre.btcdcli4j.http.client;

public interface SimpleHttpClient {
	
	String execute(String reqPayload);
}