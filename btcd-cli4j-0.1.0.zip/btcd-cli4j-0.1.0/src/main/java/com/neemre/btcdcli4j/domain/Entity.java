package com.neemre.btcdcli4j.domain;

import lombok.Data;

@Data
public abstract class Entity {

}